import {z} from 'zod';
import {env} from 'cloudflare:workers';
import {authorized,json,sameOrigin,secret,token} from '@/lib/access';
export async function GET(r:Request){return json({authenticated:await authorized(r)})}
export async function POST(r:Request){
 if(!sameOrigin(r))return json({error:'Pedido inválido.'},403);
 try{
 const {password}=z.object({password:z.string().max(200)}).parse(await r.json());const db=env.DB!;const key='login:'+ (r.headers.get('cf-connecting-ip')||r.headers.get('oai-authenticated-user-id')||'shared');const now=Date.now();
 await db.prepare('INSERT INTO attempts (key,count,until) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN until < ? THEN 1 ELSE count+1 END, until=CASE WHEN until < ? THEN ? ELSE until END').bind(key,now+300000,now,now,now+300000).run();
 const a=await db.prepare('SELECT count FROM attempts WHERE key=?').bind(key).first<{count:number}>();if(a!.count>20)return json({error:'Demasiadas tentativas. Tente dentro de 5 minutos.'},429);
 if(password!==secret('ACCESS_PASSWORD'))return json({error:'Palavra-passe incorreta.'},401);
 await db.prepare('DELETE FROM attempts WHERE key=?').bind(key).run();return Response.json({ok:true},{headers:{'Cache-Control':'no-store','Set-Cookie':`empresas_session=${await token()}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`}});
 }catch{return json({error:'Não foi possível iniciar sessão.'},500)}
}
export async function DELETE(r:Request){if(!sameOrigin(r))return json({error:'Pedido inválido.'},403);return Response.json({ok:true},{headers:{'Set-Cookie':'empresas_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'}})}
