import {env} from 'cloudflare:workers';
import {z} from 'zod';
import {authorized,json,sameOrigin,secret} from '@/lib/access';
const cat=z.object({id:z.string().min(1).max(100),name:z.string().trim().min(1).max(100)});
const company=z.object({id:z.string().min(1).max(100),name:z.string().trim().min(1).max(160),categoryId:z.string().min(1).max(100),email:z.union([z.string().trim().email().max(254),z.literal('')]).default(''),contact:z.string().trim().max(100),website:z.string().trim().max(500).refine(v=>{if(!v)return true;try{return ['https:','http:'].includes(new URL(v).protocol)}catch{return false}},'Introduza um site válido começado por https://'),notes:z.string().max(10000),image:z.string().max(700000).refine(v=>!v||/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v),'Imagem inválida.'),updatedAt:z.string().max(100).optional()});
async function read(){const db=env.DB!;const [c,b,s]=await db.batch([db.prepare('SELECT * FROM categories'),db.prepare('SELECT id,name,category_id AS categoryId,email,contact,website,notes,image,updated_at AS updatedAt FROM companies'),db.prepare("SELECT value FROM settings WHERE key='backup'")]);return {categories:c.results,companies:b.results,lastBackup:(s.results[0] as {value:string}|undefined)?.value||null}}
async function snapshot(){try{const data=await read();const at=new Date().toISOString();const content=JSON.stringify({format:'empresas-obra',version:1,exportedAt:at,...data});await env.BUCKET!.put('backups/'+at.slice(0,10)+'.json',content,{httpMetadata:{contentType:'application/json'}});await env.DB!.prepare("INSERT INTO settings (key,value) VALUES ('backup',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(at).run();return null}catch{return 'Os dados foram guardados, mas a cópia automática interna falhou. Exporte um backup manual.'}}
export async function GET(r:Request){if(!await authorized(r))return json({error:'Inicie sessão.'},401);try{return json({format:'empresas-obra',version:1,exportedAt:new Date().toISOString(),...await read()})}catch{return json({error:'Não foi possível carregar os dados. Tente atualizar.'},500)}}
export async function POST(r:Request){
 if(!sameOrigin(r))return json({error:'Pedido inválido.'},403);if(!await authorized(r))return json({error:'A sessão terminou. Volte a entrar.'},401);
 try{
 if(Number(r.headers.get('content-length')||0)>20000000)return json({error:'Ficheiro demasiado grande.'},413);
 const b=z.record(z.unknown()).parse(await r.json());const db=env.DB!;
 if(b.action==='category'){
 const c=cat.parse(b.category);const duplicate=await db.prepare('SELECT id FROM categories WHERE lower(name)=lower(?) AND id != ?').bind(c.name,c.id).first();if(duplicate)return json({error:'Essa categoria já existe.'},409);
 await db.prepare('INSERT INTO categories(id,name) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(c.id,c.name).run();
 }else if(b.action==='removeCategory'){
 const id=z.string().parse(b.id);const count=await db.prepare('SELECT id FROM companies WHERE category_id=? LIMIT 1').bind(id).first();if(count)return json({error:'Mova as empresas desta categoria antes de a eliminar.'},409);await db.prepare('DELETE FROM categories WHERE id=?').bind(id).run();
 }else if(b.action==='company'){
 const c=company.parse(b.company);if(!await db.prepare('SELECT id FROM categories WHERE id=?').bind(c.categoryId).first())return json({error:'Escolha uma categoria válida.'},400);
 const existing=await db.prepare('SELECT updated_at FROM companies WHERE id=?').bind(c.id).first<{updated_at:string}>();const now=new Date().toISOString();
 if(!existing&&c.updatedAt)return json({error:'Esta empresa foi eliminada noutro computador. Atualize a lista.'},409);
 if(existing){const result=await db.prepare('UPDATE companies SET name=?,category_id=?,email=?,contact=?,website=?,notes=?,image=?,updated_at=? WHERE id=? AND updated_at=?').bind(c.name,c.categoryId,c.email,c.contact,c.website,c.notes,c.image,now,c.id,c.updatedAt||'').run();if(!result.meta.changes)return json({error:'Esta empresa foi alterada noutro computador. Feche e atualize antes de editar.'},409)}else await db.prepare('INSERT INTO companies (id,name,category_id,email,contact,website,notes,image,updated_at) VALUES (?,?,?,?,?,?,?,?,?)').bind(c.id,c.name,c.categoryId,c.email,c.contact,c.website,c.notes,c.image,now).run();
 }else if(b.action==='remove'){
 if(b.code!==secret('DELETE_CODE'))return json({error:'Código de eliminação incorreto.'},403);const id=z.string().parse(b.id);const result=await db.prepare('DELETE FROM companies WHERE id=? AND updated_at=?').bind(id,z.string().parse(b.updatedAt)).run();if(!result.meta.changes)return json({error:'O registo foi alterado ou eliminado. Atualize a lista.'},409);
 }else if(b.action==='import'){
 const data=z.object({format:z.literal('empresas-obra'),version:z.literal(1),categories:z.array(cat).max(500),companies:z.array(company).max(2000)}).parse(b.data);
 const known=new Set(data.categories.map(c=>c.id));if(data.companies.some(c=>!known.has(c.categoryId)))return json({error:'O backup contém categorias em falta.'},400);
 const old=await read();const cats=old.categories as {id:string,name:string}[];const comps=new Set((old.companies as {id:string}[]).map(c=>c.id));
 if(data.categories.some(c=>cats.some(o=>o.id!==c.id&&o.name.toLocaleLowerCase('pt')===c.name.toLocaleLowerCase('pt'))))return json({error:'Existem categorias com o mesmo nome e identificadores diferentes. Renomeie-as antes de importar.'},409);
 const stmts=[...data.categories.filter(c=>!cats.some(o=>o.id===c.id)).map(c=>db.prepare('INSERT INTO categories (id,name) VALUES (?,?)').bind(c.id,c.name)),...data.companies.filter(c=>!comps.has(c.id)).map(c=>db.prepare('INSERT INTO companies (id,name,category_id,email,contact,website,notes,image,updated_at) VALUES (?,?,?,?,?,?,?,?,?)').bind(c.id,c.name,c.categoryId,c.email,c.contact,c.website,c.notes,c.image,new Date().toISOString()))];
 if(stmts.length)await db.batch(stmts);
 }else return json({error:'Ação inválida.'},400);
 const warning=await snapshot();return json({ok:true,warning,...await read()});
 }catch(e){if(e instanceof z.ZodError)return json({error:e.issues[0]?.message||'Dados inválidos.'},400);return json({error:'Não foi possível guardar. Atualize e tente novamente.'},500)}
}
