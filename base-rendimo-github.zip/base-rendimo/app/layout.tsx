import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Base Rendimo',description:'Base de empresas e contactos por categoria de empreitada.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-PT"><body>{children}</body></html>}
