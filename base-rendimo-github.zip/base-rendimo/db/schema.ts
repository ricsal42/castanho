import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const categories=sqliteTable('categories',{id:text('id').primaryKey(),name:text('name').notNull()});
export const companies=sqliteTable('companies',{id:text('id').primaryKey(),name:text('name').notNull(),categoryId:text('category_id').notNull().references(()=>categories.id),email:text('email').notNull(),contact:text('contact').notNull().default(''),website:text('website').notNull().default(''),notes:text('notes').notNull().default(''),image:text('image').notNull().default(''),updatedAt:text('updated_at').notNull()});
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const attempts=sqliteTable('attempts',{key:text('key').primaryKey(),count:integer('count').notNull(),until:integer('until').notNull()});
